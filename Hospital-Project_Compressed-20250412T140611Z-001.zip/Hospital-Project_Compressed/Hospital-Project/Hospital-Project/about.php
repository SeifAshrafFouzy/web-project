<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive hospital website create by win coder</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>


<section class="about" id="about">

    <h1 class="heading"> <span>about</span> us </h1>

    <div class="row">

        <div class="image">
            <img src="image/about-img.svg" alt="">
        </div>

        <div class="content">
            <h3>take the world's best quality treatment</h3>
            <div class="content">
            <p>
            Your Health, Our Priority SHAM Hospital
            is to committ to providing exceptional care for you and your loved ones. 
            With state-of-the-art facilities, a team of expert doctors, and compassionate healthcare professionals,
            we offer a wide range of services to meet all your medical needs. From routine check-ups to complex surgeries,
            we ensure the highest standards of care, safety, and comfort.
            </p>

            <br>
            <p>
            <strong> 
                
            </strong>
            </p>
           
            
            <p>
            Expert doctors in every field
            Advanced medical technology and equipment
            Compassionate, personalized care
            24/7 emergency services
            Comfortable and modern patient facilities
            Your health is in trusted hands. Experience the difference at SHAM Hospital.
            Call 01129879212 or visit our website to learn more or book an appointment today!
            SHAM Hospital Where Healing Begins.
            </p>

            </div>
           
            <a href="about_more.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
        </div>

    </div>

</section>

<section class="footer">

    <div class="box-container">

    <div class="box">
            <h3>quick links</h3>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="about.php"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="service.php"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="appointment.php"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="https://share.chatling.ai/s/V1BdWEpkmLj7ldc"> <i class="fas fa-chevron-right"></i> Chat-With-Us </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="blog.php"> <i class="fas fa-chevron-right"></i> blogs </a>
            <a href="patient-guide.html"><i class="fas fa-chevron-right"></i> patient-guide</a>
            <a href="insurance-billing.html"><i class="fas fa-chevron-right"></i> insurance</a>
        </div>

        <div class="box">
            <h3>our services</h3>
            <a href="check.html"> <i class="fas fa-chevron-right"></i> free checkups </a>
            <a href="Ambulance.html"> <i class="fas fa-chevron-right"></i> 24/7 ambulance </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> expert doctors</a>
            <a href="medicines.html"> <i class="fas fa-chevron-right"></i> medicines </a>
            <a href="care.html"> <i class="fas fa-chevron-right"></i> total care </a>  
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +01284726792 </a>
            <a href="#"> <i class="fas fa-phone"></i> +20 11 51714147</a>
            <a href="#"> <i class="fas fa-envelope"></i> Mariam-Ashraf@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> Hagar-Hussein@outllok.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Washington, D.C. </a>
        </div>


        <div class="box">
            <h3>follow us</h3>
            <a href="https://www.facebook.com"> <i class="fab fa-faceappointment-f"></i> facebook </a>
            <a href="https://www.twitter.com""> <i class="fab fa-twitter"></i> twitter </a>
            <a href="https://www.instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="https://www.linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
        </div>

    </div>

    <div class="credit"> created by <span> SHAM Company </span> | all rights reserved </div>

</section>

<!-- footer section ends -->


<!-- js file link  -->

<!-- js file link  -->
<script src="js/script.js"></script>



</body>
</html>


<script> window.chtlConfig = { chatbotId: "8197453941" } </script>
<script async data-id="8197453941" id="chatling-embed-script" type="text/javascript" src="https://chatling.ai/js/embed.js"></script>