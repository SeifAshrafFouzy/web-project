document.getElementById("register-form").addEventListener("submit", function(event) {
    const firstName = document.getElementById("first-name").value;
    const lastName = document.getElementById("last-name").value;
    const dob = document.getElementById("dob").value;
    const job = document.getElementById("job").value;
    const address = document.getElementById("address").value;
    const phone = document.getElementById("phone").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    // Clear previous error message
    document.getElementById("error-message").textContent = "";

    // Basic validation
    if (firstName === "" || lastName === "" || dob === "" || job === "" || address === "" || phone === "" || email === "" || password === "" || confirmPassword === "") {
        event.preventDefault();
        document.getElementById("error-message").textContent = "Please fill in all fields.";
        return;
    }

    if (password !== confirmPassword) {
        event.preventDefault();
        document.getElementById("error-message").textContent = "Passwords do not match.";
    }
});

