<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Card Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .form-group input[type="text"], .form-group input[type="date"] {
            width: 48%;
            margin-right: 4%;
        }
        .form-group input[type="text"]:last-child {
            margin-right: 0;
        }
        .form-group button {
            width: 100%;
            padding: 15px;
            background-color: #4CAF50;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #45a049;
        }
        .form-group input:focus, .form-group button:focus {
            outline: none;
            border-color: #4CAF50;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Bank Card Payment</h2>
        <form action="submit_payment.php" method="POST">
            <div class="form-group">
                <label for="cardNumber">Card Number</label>
                <input type="text" id="cardNumber" name="cardNumber" placeholder="1234 5678 9876 5432" required>
            </div>

            <div class="form-group">
                <label for="expDate">Expiration Date</label>
                <input type="date" id="expDate" name="expDate" required>
            </div>

            <div class="form-group">
                <label for="cardHolder">Cardholder Name</label>
                <input type="text" id="cardHolder" name="cardHolder" placeholder="John Doe" required>
            </div>

            <div class="form-group">
                <label for="cvv">CVV (Security Code)</label>
                <input type="text" id="cvv" name="cvv" placeholder="123" required>
            </div>

            <div class="form-group">
                <button type="submit">Pay Now</button>
            </div>
        </form>
    </div>

</body>
</html>