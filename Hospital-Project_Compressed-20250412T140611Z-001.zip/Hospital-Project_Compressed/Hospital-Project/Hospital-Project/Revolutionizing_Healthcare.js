// Highlight active section in the "On this Page" list
document.addEventListener("scroll", () => {
    const sections = document.querySelectorAll("main section");
    const tocLinks = document.querySelectorAll("#toc a");
  
    let currentSection = "";
  
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 100;
      if (window.scrollY >= sectionTop) {
        currentSection = section.getAttribute("id");
      }
    });
  
    tocLinks.forEach(link => {
      link.classList.remove("active");
      if (link.getAttribute("href").substring(1) === currentSection) {
        link.classList.add("active");
      }
    });
  });
  
  // Add "active" styling
  const style = document.createElement("style");
  style.innerHTML = `
    #toc a.active {
      color: #ff5722;
      font-weight: bold;
    }
  `;

  // Scroll to the top of the page
document.getElementById("scroll-up").addEventListener("click", () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  });
  
  // Scroll to the bottom of the page
  document.getElementById("scroll-down").addEventListener("click", () => {
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth",
    });
  });
  


  
  document.head.appendChild(style);
  