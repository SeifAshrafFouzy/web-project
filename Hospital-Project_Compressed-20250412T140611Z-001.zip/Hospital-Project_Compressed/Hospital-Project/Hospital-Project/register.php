<?php
// Database connection settings
$servername = "localhost";
$db_username = "root";  // Your MySQL username
$db_password = "";      // Your MySQL password
$dbname = "user2_db";

// Create a connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $dob = $_POST['dob'];
    $job = $_POST['job'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm-password'];

    // Sanitize user input to prevent SQL injection
    $first_name = $conn->real_escape_string($first_name);
    $last_name = $conn->real_escape_string($last_name);
    $dob = $conn->real_escape_string($dob);
    $job = $conn->real_escape_string($job);
    $address = $conn->real_escape_string($address);
    $phone = $conn->real_escape_string($phone);
    $email = $conn->real_escape_string($email);
    $password = $conn->real_escape_string($password);
    $confirmPassword = $conn->real_escape_string($confirmPassword);

    // Check if passwords match
    if ($password !== $confirmPassword) {
        echo "Passwords do not match.";
    } else {
        // Hash the password for secure storage
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check if the email already exists
        $checkEmailSql = "SELECT * FROM users3 WHERE email='$email'";
        $result = $conn->query($checkEmailSql);

        if ($result->num_rows > 0) {
            echo "Email already exists.";
        } else {
            // Insert new user into the database
            $sql = "INSERT INTO users3 (first_name, last_name, dob, job, address, phone, email, password) 
                    VALUES ('$first_name', '$last_name', '$dob', '$job', '$address', '$phone', '$email', '$hashedPassword')";

            if ($conn->query($sql) === TRUE) {

                // echo "Registration successful! <a href='login.html'>Login here</a>";

                // Display the alert message and redirect to the next page
                echo "<script>
                alert('Registration successful! You will be redirected to the login page.');
                window.location.href = 'login.php'; // Change 'login.php' to your desired URL
                </script>";
            } else {
                echo "Error: " . $conn->error;
            }
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    

    <div class="register-container">
    <div class="image">
        <img src="image/home-img.svg" alt="">
    </div>

        <h2>Create Account</h2>
        <form id="register-form" method="POST" action="register.php">
            <div class="form-group">
                <label for="first-name">First Name:</label>
                <input type="text" id="first-name" name="first_name" required>
            </div>
            <div class="form-group">
                <label for="last-name">Last Name:</label>
                <input type="text" id="last-name" name="last_name" required>
            </div>
            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="dob" required>
            </div>
            <div class="form-group">
                <label for="job">Job:</label>
                <input type="text" id="job" name="job" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <textarea id="address" name="address" required></textarea>
            </div>
            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm Password:</label>
                <input type="password" id="confirm-password" name="confirm-password" required>
            </div>
            <button type="submit">Register</button>
            <p id="error-message"></p>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>
