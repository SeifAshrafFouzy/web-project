<!--
<form method="post">      
            <h3>make appointment</h3>
            <input type="text"name="name" placeholder="your name" class="box">
            <input type="number"name="number" placeholder="your number" class="box">
            <input type="email"name="email" placeholder="your email" class="box">
            <input type="date"name="date" class="box">
            
            <br><br>
            <div class="content">
                
            <h1>
                 Select the <strong> department(s) </strong> you need for your health case 
            </h1>
            
             </div>
             <div class="Mop">
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Psychiatry Department ">  Psychiatry Department </h4> 
            <br>
            <h4><input type="checkbox" name="departments[]" value=" Pediatrics Department " class="Mop">  Pediatrics Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Cardiology Department " class="Mop">  Cardiology Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Neurology Department " class="Mop">  Neurology Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Oncology Department " class="Mop">  Oncology Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Orthopedics Department " class="Mop">  Orthopedics Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Gastroenterology Department " class="Mop">  Gastroenterology Department </h4>
            <br>
            <h4><input type="checkbox" name="departments[]" value=" Pharmacy Department " class="Mop">  Pharmacy Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Dermatology Department " class="Mop">  Dermatology Department  </h4>
            </div>
            <br>
            <input type="submit" name="submit" value="appointment now" class="btn">
            
        </form>


-->


<?php
if (isset($_POST['submit'])) {
    // Collect the form data
    $name = $_POST['name'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $date = $_POST['date'];
    
    // Collect selected departments (checkboxes)
    $departments = isset($_POST['departments']) ? implode(", ", $_POST['departments']) : "";

    // Database connection
    $servername = "localhost";
    $username = "root";  // Your MySQL username
    $password = "";  // Your MySQL password
    $dbname = "appointments_db";  // Your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert data into the database
    $sql = "INSERT INTO appointments (name, number, email, date, departments) 
            VALUES ('$name', '$number', '$email', '$date', '$departments')";

    if ($conn->query($sql) === TRUE) {
        // On successful insertion, show the alert and redirect
        echo "<script>
            alert('Appointment successfully booked!');
            window.location.href = 'appointment.php'; // Change to your desired redirect URL
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive hospital website create by win coder</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>


<section class="appointment" id="appointment">

    <h1 class="heading"> <span>appointment</span> now </h1>    

    <h4 class="heading"> <span>Register now </span> Pay at anytime </h4>    


    <div class="row">

        <div class="image">
            <img src="image/appointment-img.svg" alt="">
        </div>

        <!-- 
           <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
        <?php
            if(isset($message)) {
                foreach($message as $message) {
                echo'<p class ="message">'.$message.'</p>';
            }
            }
        ?>
        -->
        <form method="post">      
            <h3>make appointment</h3>
            <input type="text"name="name" placeholder="your name" class="box">
            <input type="number"name="number" placeholder="your number" class="box">
            <input type="email"name="email" placeholder="your email" class="box">
            <input type="date"name="date" class="box">
            
            <br><br>
            <div class="content">
                
            <h1>
                 Select the <strong> department(s) </strong> you need for your health case 
            </h1>
            
             </div>
             <div class="Mop">
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Psychiatry Department ">  Psychiatry Department </h4> 
            <br>
            <h4><input type="checkbox" name="departments[]" value=" Pediatrics Department " class="Mop">  Pediatrics Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Cardiology Department " class="Mop">  Cardiology Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Neurology Department " class="Mop">  Neurology Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Oncology Department " class="Mop">  Oncology Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Orthopedics Department " class="Mop">  Orthopedics Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Gastroenterology Department " class="Mop">  Gastroenterology Department </h4>
            <br>
            <h4><input type="checkbox" name="departments[]" value=" Pharmacy Department " class="Mop">  Pharmacy Department </h4>
            <br>
            <h4> <input type="checkbox" name="departments[]" value=" Dermatology Department " class="Mop">  Dermatology Department  </h4>
            </div>
            <br>
            <input type="submit" name="submit" value="appointment now" class="btn">
            <br>
            <button type="submit">
            <a href="Payment.php"  class="btn">
            Paying Online Now 
            </a>
            </button>
    </a>
    <br><br>
         <p class="Mop"> Reservation per Department : 150 dollars</p>
            
        </form>

</section>


<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="about.php"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="service.php"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="appointment.php"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="https://share.chatling.ai/s/V1BdWEpkmLj7ldc"> <i class="fas fa-chevron-right"></i> Chat-With-Us </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="blog.php"> <i class="fas fa-chevron-right"></i> blogs </a>
            <a href="patient-guide.html"><i class="fas fa-chevron-right"></i> patient-guide</a>
            <a href="insurance-billing.html"><i class="fas fa-chevron-right"></i> insurance</a>
        </div>
        <div class="box">
            <h3>our services</h3>
            <a href="check.html"> <i class="fas fa-chevron-right"></i> free checkups </a>
            <a href="Ambulance.html"> <i class="fas fa-chevron-right"></i> 24/7 ambulance </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> expert doctors</a>
            <a href="medicines.html"> <i class="fas fa-chevron-right"></i> medicines </a>
            <a href="care.html"> <i class="fas fa-chevron-right"></i> total care </a>  
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="https://www.facebook.com"> <i class="fab fa-faceappointment-f"></i> facebook </a>
            <a href="https://www.twitter.com""> <i class="fab fa-twitter"></i> twitter </a>
            <a href="https://www.instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="https://www.linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +01284726792 </a>
            <a href="#"> <i class="fas fa-phone"></i> +20 11 51714147</a>
            <a href="#"> <i class="fas fa-envelope"></i> Mariam-Ashraf@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> Hagar-Hussein@outllok.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Washington, D.C. </a>
        </div>
 
    </div>
    <div class="credit"> created by <span> SHAM Company </span> | all rights reserved </div>
</section>

<!-- footer section ends -->


<!-- js file link  -->


<!-- js file link  -->
<script src="js/script.js"></script>



</body>
</html>



<script> window.chtlConfig = { chatbotId: "8197453941" } </script>
<script async data-id="8197453941" id="chatling-embed-script" type="text/javascript" src="https://chatling.ai/js/embed.js"></script>