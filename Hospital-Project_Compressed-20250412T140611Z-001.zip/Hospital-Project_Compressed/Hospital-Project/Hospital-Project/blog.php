
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive hospital website create by win coder</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    


<section class="blogs" id="blogs">

    <h1 class="heading"> our <span>blogs</span> </h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="image/blog-1.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="https://calendar.google.com/calendar/u/0/r?pli=1"> <i class="fas fa-calendar"></i> 21 December, 2020 </a>
                    <a href=""> <i class="fas fa-user"></i> By Hector Bernal </a>
                </div>
                <h3>
                Title: "Revolutionizing Healthcare: The Role of Advanced Laboratories in Modern Medicine"
                </h3>
<!--
                
-->
                <a href="Revolutionizing_Healthcare.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="image/blog-2.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="https://calendar.google.com/calendar/u/0/r?pli=1"> <i class="fas fa-calendar"></i> 20 October, 2022 </a>
                    <a href="#"> <i class="fas fa-user"></i> By Natalya Fernández </a>
                </div>
                <h3> Title : "A Legacy of Healing: The Impact of Dr.[William Beaumont] on Modern Medicine" </h3>
                <a href="Legacy_of_Healing.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>


        <div class="box">
            <div class="image">
                <img src="image/blog-3.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                <a href="https://calendar.google.com/calendar/u/0/r?pli=1"> <i class="fas fa-calendar"></i> 25 April, 20223</a>
                    <a href="#"> <i class="fas fa-user"></i> By Carla García </a>
                </div>
                <h3>Title: "A Day in the Life of Dr. [William Beaumont]: The Daily Routine of a Renowned Medical Professional"</h3>
                <a href="William_Beaumont.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="image/blog-4.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="https://calendar.google.com/calendar/u/0/r?pli=1"> <i class="fas fa-calendar"></i> 26 Mai , 2022 </a>
                    <a href="#"> <i class="fas fa-user"></i> By Johann Zimmer </a>
                </div>
                <h3> Title : "Leveraging Social Media for Hospital Marketing: A Modern Approach to Patient Engagement"</h3>
                <a href="Social_Media.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img src="image/blog-5.jpg" alt="">
            </div>
            <div class="content">
                <div class="icon">
                    <a href="#"> <i class="fas fa-calendar"></i> 21 November, 2024 </a>
                    <a href="#"> <i class="fas fa-user"></i> By Terso Jiménez </a>
                </div>
                <h3>
                "The Power of Teamwork in Healthcare: Celebrating the Collaborative Efforts of Doctors"
                </h3>
                <a href="Teamwork.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </div>
        </div>
        

    </div>

</section>


<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="about.php"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="service.php"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="appointment.php"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="https://share.chatling.ai/s/V1BdWEpkmLj7ldc"> <i class="fas fa-chevron-right"></i> Chat-With-Us </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="blog.php"> <i class="fas fa-chevron-right"></i> blogs </a>
            <a href="patient-guide.html"><i class="fas fa-chevron-right"></i> patient-guide</a>
            <a href="insurance-billing.html"><i class="fas fa-chevron-right"></i> insurance</a>
        </div>

        <div class="box">
            <h3>our services</h3>
            <a href="check.html"> <i class="fas fa-chevron-right"></i> free checkups </a>
            <a href="Ambulance.html"> <i class="fas fa-chevron-right"></i> 24/7 ambulance </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> expert doctors</a>
            <a href="medicines.html"> <i class="fas fa-chevron-right"></i> medicines </a>
            <a href="care.html"> <i class="fas fa-chevron-right"></i> total care </a>  
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +01284726792 </a>
            <a href="#"> <i class="fas fa-phone"></i> +20 11 51714147</a>
            <a href="#"> <i class="fas fa-envelope"></i> Mariam-Ashraf@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> Hagar-Hussein@outllok.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Washington, D.C. </a>
        </div>


        <div class="box">
            <h3>follow us</h3>
            <a href="https://www.facebook.com""> <i class="fab fa-facebook"></i> facebook </a>
            <a href="https://www.twitter.com""> <i class="fab fa-twitter"></i> twitter </a>
            <a href="https://www.instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="https://www.linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
        </div>

        <!--
                    <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>       
        -->
    </div>

    <div class="credit"> created by <span> SHAM Company </span> | all rights reserved </div>

</section>

<!-- footer section ends -->


<!-- js file link  -->
<script src="js/script.js"></script>



</body>
</html>


<script> window.chtlConfig = { chatbotId: "8197453941" } </script>
<script async data-id="8197453941" id="chatling-embed-script" type="text/javascript" src="https://chatling.ai/js/embed.js"></script>