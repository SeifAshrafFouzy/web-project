<?php

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive hospital website create by win coder</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> <strong> SHAM </strong> Group of Hospitals </a>

    <nav class="navbar">
        <a href="index.php">home</a>
        <a href="about.php">about</a>
        <a href="service.php">services</a>
        <a href="index.php">doctors</a>
        <a href="appointment.php">appointment</a>
        <a href="https://share.chatling.ai/s/V1BdWEpkmLj7ldc">Chat-With-Us</a>
        <a href="index.php">review</a>
        <a href="patient-guide.html">patient-guide</a>
        <a href="insurance-billing.html">insurance</a>
        <a href="blog.php">blogs</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="image">
        <img src="image/home-img.svg" alt="">
    </div>



<!--
     <h3>Dr. Martina Gonzalez</h3>
            <span>Head of Pediatrics Department</span>
-->
    <div class="content">
        <h3>Our Departments are ready for caring about your health</h3>

        <p><strong> 1. Emergency Department (ED): </strong> Provides immediate care for urgent and critical health issues, including trauma,
         heart attacks, strokes, and accidents. </p>
        <p><strong> 2. Surgical Department: </strong>
        Handles operations and surgeries, including general surgery, orthopedics, neurosurgery, and more.
        </p>
        <p><strong>  
        3. Psychiatry Department : 
        </strong> 
        Provides care for individuals with mental health disorders, offering counseling, medication management, and therapy.
        </p>

        <p><strong> 4. Pediatrics Department : </strong>  Specializes in the medical care of infants, children, and adolescents. </p>
        <p><strong> 5. Cardiology Department: </strong> Deals with heart-related conditions, including diagnostics, treatments, and interventions for heart disease and related disorders. </p>
        <p><strong> 6. Neurology Department : </strong>  Focuses on the diagnosis and treatment of neurological disorders, including strokes, epilepsy, and brain injuries. </p>
        <p><strong>
        7. Oncology Department: 
        </strong> Specializes in the diagnosis, treatment, and management of cancer. </p>
        <p><strong>  </strong>  </p>
        <p><strong> 8. Orthopedics Department: </strong>  Deals with the treatment of musculoskeletal problems, including bones, joints, ligaments, and muscles. </p>
        <p><strong> 9. Gastroenterology Department: </strong>   Specializes in the treatment of the digestive system, including the stomach, intestines, liver, and pancreas. </p>
        
        <p><strong> 10. Pharmacy Department: </strong> 
         Manages medications, ensuring safe and effective drug dispensing, and provides advice on proper medication use.
        
         <p><strong> 11. Dermatology Department: </strong> 
         Deals with skin conditions, including acne, eczema, psoriasis, and skin cancer.
         <br>
        <a href="appointment.php" class="btn"> appointment us <span class="fas fa-chevron-right"></span> </a>
    </div>

</section>

<!-- home section ends -->

<!-- icons section starts  -->

<section class="icons-container">

    <div class="icons">
        <i class="fas fa-user-md"></i>
        <h3>150+</h3>
        <p>doctors at work</p>
    </div>

    <div class="icons">
        <i class="fas fa-users"></i>
        <h3>1030+</h3>
        <p>satisfied patients</p>
    </div>

    <div class="icons">
        <i class="fas fa-procedures"></i>
        <h3>490+</h3>
        <p>bed facility</p>
    </div>

    <div class="icons">
        <i class="fas fa-hospital"></i>
        <h3>70+</h3>
        <p>available hospitals</p>
    </div>

</section>

<!-- icons section ends -->

<!-- about section starts  -->

<!--
96

-->

<!-- about section ends -->

<!-- services section starts  -->

<!--
105
-->

<!-- services section ends -->



<!-- doctors section starts  -->

<section class="doctors" id="doctors">

    <h1 class="heading"> our <span> doctors</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/doc-1.jpg" alt="">
            <h3> Dr. Martina Gonzalez </h3>
            <span>Head of Pediatrics Department</span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
                
            </div>
        </div>

        <div class="box">
            <img src="image/doc-2.jpg" alt="">
            <h3> Dr. Hans Hoffman </h3>
            <span> Head of Cardiology Department </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-3.jpg" alt="">
            <h3> Dr. Elsa Wiegend </h3>
            <span> Head Of Psychiatry Department </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-4.jpg" alt="">
            <h3> Dr. Leonara Rosfelt </h3>
            <span> Head Of Pharmacy Department: </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-5.jpg" alt="">
            <h3> Dr. George Garza </h3>
            <span> Head of Neurology Department </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>




        <div class="box">
            <img src="image/doc-6.jpg" alt="">
            <h3> Dr. Michael DeBakey  </h3>
            <span> Head Of Surgical Department and Emergency Department </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>


        <div class="box">
            <img src="image/doc-7.jpg" alt="">
            <h3> Dr. Elena Colerio </h3>
            <span> Head Of Oncology Department  </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>
        <div class="box">
            <img src="image/doc-8.jpg" alt="">
            <h3> Dr. Albert Steinberg </h3>
            <span> Head Of Dermatology Department </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>
        <div class="box">
            <img src="image/doc-9.jpg" alt="">
            <h3> William Beaumont </h3>
            <span> Head Of Gastroenterology Department </span>
            <div class="share">
            <a href="https://www.facebook.com" class="fab fa-facebook-f"></a>
            <a href="https://www.twitter.com" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com" class="fab fa-instagram"></a>
            <a href="https://www.linkedin.com" class="fab fa-linkedin"></a>
            </div>
        </div>

    </div>

</section>

<!-- doctors section ends -->

<!-- appointmenting section starts   -->



<!--
302
-->




<!-- appointmenting section ends -->

<!-- review section starts  -->

<section class="review" id="review">
    
    <h1 class="heading"> client's <span>review</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/MV5BZTE0NTdhNGQtODY2MC00NGVjLTk2NjYtYjMwMmRjOTg2NzNhXkEyXkFqcGdeQXJoYW5uYWg@._V1_QL75_UX500_CR0,0,500,281_.jpg" alt="">
            <h3> Selena Gomez </h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <p class="text">
            Selena Gomez has been open about her battle with lupus, an autoimmune disease,
            which led to her needing a kidney transplant in 2017. She has since used her platform to raise awareness about lupus and mental health.
                </p>
        </div>

        <div class="box">
            <img src="image/images (1).jpg" alt="">
            <h3> Alec Baldwin </h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
                <!-- 
                   <i class="fas fa-star-half-alt"></i>
-->
             
            </div>
            <p class="text">
            Alec Baldwin has publicly shared his struggles with chronic Lyme disease,
             which he was diagnosed with in the 1990s after being bitten by a tick.
                </p>
        </div>

        <div class="box">
            <img src="image/lady-gaga-2.jpg" alt="">
            <h3> Lady Gaga </h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <p class="text">
            Lady Gaga has opened up about her battle with fibromyalgia, 
            a chronic pain condition that causes widespread pain throughout the body. She has been an advocate for raising awareness of the disease.
            </p>
        </div>

    </div>

</section>


<!-- review section ends -->

<!-- blogs section starts  -->



<!-- blogs section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="about.php"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="service.php"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="appointment.php"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="https://share.chatling.ai/s/V1BdWEpkmLj7ldc"> <i class="fas fa-chevron-right"></i> Chat-With-Us </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="blog.php"> <i class="fas fa-chevron-right"></i> blogs </a>
            <a href="patient-guide.html"><i class="fas fa-chevron-right"></i> patient-guide</a>
            <a href="insurance-billing.html"><i class="fas fa-chevron-right"></i> insurance</a>
        </div>


        <div class="box">
            <h3>our services</h3>
            <a href="check.html"> <i class="fas fa-chevron-right"></i> free checkups </a>
            <a href="Ambulance.html"> <i class="fas fa-chevron-right"></i> 24/7 ambulance </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> expert doctors</a>
            <a href="medicines.html"> <i class="fas fa-chevron-right"></i> medicines </a>
            <a href="care.html"> <i class="fas fa-chevron-right"></i> total care </a>  
            
        </div>

       

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +01284726792 </a>
            <a href="#"> <i class="fas fa-phone"></i> +20 11 51714147</a>
            <a href="#"> <i class="fas fa-envelope"></i> Mariam-Ashraf@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> Hagar-Hussein@outllok.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Washington, D.C. </a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="https://www.facebook.com"> <i class="fab fa-faceappointment-f"></i> facebook </a>
            <a href="https://www.twitter.com""> <i class="fab fa-twitter"></i> twitter </a>
            <a href="https://www.instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="https://www.linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

    </div>

    <div class="credit"> created by <span> SHAM Company </span> | all rights reserved </div>

</section>

<!-- footer section ends -->


<!-- js file link  -->
<script src="js/script.js"></script>



</body>
</html>


<script> window.chtlConfig = { chatbotId: "8197453941" } </script>
<script async data-id="8197453941" id="chatling-embed-script" type="text/javascript" src="https://chatling.ai/js/embed.js"></script>