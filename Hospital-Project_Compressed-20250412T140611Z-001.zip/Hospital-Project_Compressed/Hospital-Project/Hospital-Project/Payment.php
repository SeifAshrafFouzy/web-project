<?php
// MySQL Database connection details
$servername = "localhost";
$username = "root"; // Database username
$password = ""; // Database password
$dbname = "payment_details2"; // Database name

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for database connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize the form data
    $amount = $_POST['amount'];  // Amount to be paid
    $cardNumber = $_POST['cardNumber'];  // Card number
    $expDate = $_POST['expDate'];  // Expiration Date
    $cardHolder = $_POST['cardHolder'];  // Cardholder's name
    $cvv = $_POST['cvv'];  // CVV

    // Basic validation (Optional: You can improve it with more validation)
    if (empty($amount) || empty($cardNumber) || empty($expDate) || empty($cardHolder) || empty($cvv)) {
        echo "All fields are required!";
        exit;
    }

    // SQL query to insert the payment details into the database
    $sql = "INSERT INTO payment_details2 (amount, card_number, exp_date, cardholder_name, cvv) 
            VALUES ('$amount', '$cardNumber', '$expDate', '$cardHolder', '$cvv')";

    // Execute the query and check for success
    if ($conn->query($sql) === TRUE) {
        echo "Payment details saved successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive hospital website create by win coder</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 30px;
        }
        .form-group label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .form-group input[type="text"], .form-group input[type="date"] {
            width: 48%;
            margin-right: 4%;
        }
        .form-group input[type="text"]:last-child {
            margin-right: 0;
        }
        .form-group button {
            width: 100%;
            padding: 15px;
            background-color: #4CAF50;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #45a049;
        }
        .form-group input:focus, .form-group button:focus {
            outline: none;
            border-color: #4CAF50;
        }
    </style>

</head>
<body>


<section class="appointment" id="appointment">

    <h1 class="heading"> <span>Paymant</span> Via Visa or Mastercard </h1>    

    


    <div class="row">

        <div class="image">
            <img src="image/appointment-img.svg" alt="">
        </div>

        <!-- 
           <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
        <?php
            if(isset($message)) {
                foreach($message as $message) {
                echo'<p class ="message">'.$message.'</p>';
            }
            }
        ?>
        -->
        <form method="post">      
            <h3> Bank Card Data</h3>
            
            <div class="form-group" class="Mop">
                <label for="cardNumber" class="Mop">Amount of money to be paid</label>
                <input type="text" id="cardNumber" name="amount" placeholder="1000$" required >
            </div>

        
            <div class="form-group" class="Mop">
                <label for="cardNumber" class="Mop">Card Number</label>
                <input type="text" id="cardNumber" name="cardNumber" placeholder="1234 5678 9876 5432" required >
            </div>

            <div class="form-group" class="Mop">
                <label for="expDate" class="Mop">Expiration Date</label>
                <input type="date" id="expDate" name="expDate" required>
            </div>

            <div class="form-group" class="Mop">
                <label for="cardHolder" class="Mop">Cardholder Name</label>
                <input type="text" id="cardHolder" name="cardHolder" placeholder="John Doe" required>
            </div>

            <div class="form-group" class="Mop">
                <label for="cvv" class="Mop">CVV (Security Code)</label>
                <input type="text" id="cvv" name="cvv" placeholder="123" required>
            </div>

            <div class="form-group" class="Mop">
                <button type="submit" class="Mop">Pay Now</button>
            </div>
            
         
            
        </form>

</section>


<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="about.php"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="service.php"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="appointment.php"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="https://share.chatling.ai/s/V1BdWEpkmLj7ldc"> <i class="fas fa-chevron-right"></i> Chat-With-Us </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="blog.php"> <i class="fas fa-chevron-right"></i> blogs </a>
            <a href="patient-guide.html"><i class="fas fa-chevron-right"></i> patient-guide</a>
            <a href="insurance-billing.html"><i class="fas fa-chevron-right"></i> insurance</a>
        </div>
        <div class="box">
            <h3>our services</h3>
            <a href="check.html"> <i class="fas fa-chevron-right"></i> free checkups </a>
            <a href="Ambulance.html"> <i class="fas fa-chevron-right"></i> 24/7 ambulance </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> expert doctors</a>
            <a href="medicines.html"> <i class="fas fa-chevron-right"></i> medicines </a>
            <a href="care.html"> <i class="fas fa-chevron-right"></i> total care </a>  
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="https://www.facebook.com"> <i class="fab fa-faceappointment-f"></i> facebook </a>
            <a href="https://www.twitter.com""> <i class="fab fa-twitter"></i> twitter </a>
            <a href="https://www.instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="https://www.linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +01284726792 </a>
            <a href="#"> <i class="fas fa-phone"></i> +20 11 51714147</a>
            <a href="#"> <i class="fas fa-envelope"></i> Mariam-Ashraf@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> Hagar-Hussein@outllok.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Washington, D.C. </a>
        </div>
 
    </div>
    <div class="credit"> created by <span> SHAM Company </span> | all rights reserved </div>
</section>

<!-- footer section ends -->


<!-- js file link  -->


<!-- js file link  -->
<script src="js/script.js"></script>



</body>
</html>


