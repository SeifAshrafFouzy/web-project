<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>complete responsive hospital website create by win coder</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>



<section class="services" id="services">

    <h1 class="heading"> our <span> Services </span> </h1>

    <div class="box-container">

        <div class="box">
            <i class="fas fa-notes-medical"></i>
            <h3>free checkups</h3>
            <p>
            Free checkups are medical assessments provided at no cost to individuals, typically to promote preventive healthcare, 
            early detection of health conditions, or to ensure access to healthcare services for underserved populations. 
            These checkups often include basic health screenings such as blood pressure, cholesterol levels, glucose tests, vision, and hearing assessments,
            as well as general physical exams. 
            <a href="check.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </p>
<!--
       
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>     
             <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
-->

        </div>

        <div class="box">
            <i class="fas fa-ambulance"></i>
            <h3>24/7 ambulance</h3>
            <p>
             A 24/7 ambulance service offering free checkups provides round-the-clock emergency medical assistance along with access to basic
             health screenings at no cost. This service aims to ensure that individuals,regardless of their financial situation, 
             can receive timely medical evaluations and urgent care whenever needed.The goal is to improve public health access and support early diagnosis. 
             <a href="Ambulance.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </p>
           
        </div>
        

     
                <!--
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>    
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a> 



               <div class="box">
            <i class="fas fa-user-md"></i>
            <h3>expert doctors</h3>
            <p>Expert doctors are highly skilled medical professionals with advanced knowledge and experience in their specialized fields.
               They undergo extensive education and training, often including years of hands-on practice and research.
                These doctors are recognized for their expertise in diagnosing complex medical conditions, recommending treatments, 
                and providing patient care.</p>
                  </div>
        
-->
            
      
        
        <div class="box">
            <i class="fas fa-procedures"></i>
            <h3>bed facility</h3>
            <p>
            A bed facility refers to a healthcare service or establishment that provides patients with a place to stay and
            rest while receiving medical care or treatment. Bed facilities ensure comfort and access to essential medical equipment,
            nursing care, and support services.They play a crucial role in managing acute illnesses, surgeries, and long-term health conditions,
            offering a safe and supportive environment for recovery and treatment.
            <br>
            <a href="bed_facility.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </p>

                            <!--
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            <a href="#" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
-->
            
        </div>

        <div class="box">
            <i class="fas fa-heartbeat"></i>
            <h3> total care </h3>
            <p> Total care refers to a comprehensive approach to healthcare that addresses all aspects of a patient's well-being. 
                It involves not only the treatment of physical ailments but also includes mental, emotional, and social support. 
                Total care ensures that every aspect of a patient's health is considered, from prevention and diagnosis to ongoing treatment 
                and rehabilitation. 
                <a href="care.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
            </p>
            
        </div>

        <div class="box">
            <i class="fas fa-pills"></i>
            <h3>medicines</h3>
            <p>
            Providing medicines involves the distribution and administration of pharmaceutical drugs 
            to individuals for the treatment or management of medical conditions. 
            This process includes prescribing the appropriate medications based on a patient's diagnosis, ensuring proper dosage and timing, 
            and offering guidance on potential side effects and interactions.   
            </p>
            <a href="medicines.html" class="btn"> learn more <span class="fas fa-chevron-right"></span> </a>
        </div>


    </div>

</section>

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="about.php"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="service.php"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> doctors </a>
            <a href="appointment.php"> <i class="fas fa-chevron-right"></i> appointment </a>
            <a href="https://share.chatling.ai/s/V1BdWEpkmLj7ldc"> <i class="fas fa-chevron-right"></i> Chat-With-Us </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> review </a>
            <a href="blog.php"> <i class="fas fa-chevron-right"></i> blogs </a>
            <a href="patient-guide.html"><i class="fas fa-chevron-right"></i> patient-guide</a>
            <a href="insurance-billing.html"><i class="fas fa-chevron-right"></i> insurance</a>
        </div>

        <div class="box">
            <h3>our services</h3>
            <a href="Legacy_of_Healing.html"> <i class="fas fa-chevron-right"></i> free checkups </a>
            <a href="Ambulance.html"> <i class="fas fa-chevron-right"></i> 24/7 ambulance </a>
            <a href="index.php"> <i class="fas fa-chevron-right"></i> expert doctors</a>
            <a href="medicines.html"> <i class="fas fa-chevron-right"></i> medicines </a>
            <a href="care.html"> <i class="fas fa-chevron-right"></i> total care </a>  
        </div>

        <div class="box">
            <h3>appointment info</h3>
            <a href="#"> <i class="fas fa-phone"></i> +01284726792 </a>
            <a href="#"> <i class="fas fa-phone"></i> +20 11 51714147</a>
            <a href="#"> <i class="fas fa-envelope"></i> Mariam-Ashraf@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> Hagar-Hussein@outllok.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Washington, D.C. </a>
        </div>


        <div class="box">
            <h3>follow us</h3>
            <a href="https://www.facebook.com""> <i class="fab fa-facebook"></i> facebook </a>
            <a href="https://www.twitter.com""> <i class="fab fa-twitter"></i> twitter </a>
            <a href="https://www.instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="https://www.linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
        </div>

    </div>

    <div class="credit"> created by <span> SHAM Company </span> | all rights reserved </div>

</section>

<!-- footer section ends -->


<!-- js file link  -->

<!-- footer section ends -->


<!-- js file link  -->

<!-- js file link  -->
<script src="js/script.js"></script>



</body>
</html>


<script> window.chtlConfig = { chatbotId: "8197453941" } </script>
<script async data-id="8197453941" id="chatling-embed-script" type="text/javascript" src="https://chatling.ai/js/embed.js"></script>