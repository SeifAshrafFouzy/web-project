<?php
// Database connection settings
$servername = "localhost";
$db_username = "root";  // Your MySQL username
$db_password = "";      // Your MySQL password
$dbname = "user2_db";

// Create a connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize user input to prevent SQL injection
    $email = $conn->real_escape_string($email);
    $password = $conn->real_escape_string($password);

    // Fetch user data from database
    $sql = "SELECT * FROM users3 WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
         //   echo "Login successful!";
         echo "<script>
                alert('login successful! Welcome .');
                window.location.href = 'index.php'; // Change 'login.php' to your desired URL
                </script>";
        } else {
            //echo "Invalid password.";
            echo "<script>
                alert('Invalid password! Please try again');
                window.location.href = 'login.php'; // Change 'login.php' to your desired URL
                </script>";
        }
    } 
    else {
        //echo "No user found with this email please sign up now";
        echo "<script>
                alert('Invalid email or password ! Please try again');
                window.location.href = 'login.php'; // Change 'login.php' to your desired URL
                </script>";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
   
        <div class="register-container">


            <div class="image">
                <img src="image/about-img.svg" alt="">
            </div>

  
        <h2>Login</h2>
        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
            <p id="error-message"></p>
<!-- #region 
 -->
            <div>

            <button class="redirect-button" onclick="window.location.href='register.php'">
                 Sign Up
            </button>

            <!--
            <button type="submit"> Sign Up </button>
            <p id="error-message">
-->
            </p>
            </div>



        </form>
    </div>
</body>
</html>
